E-Commerce Inventory Management System with Complex DataBase
where admin can manage 


name          :Pathipaka Sai Krishna
rollnumber    :21311a05v0
port for backend :8080
routes used for frontend execution


      http://localhost:3000/login
      http://localhost:3000/register
      http://localhost:3000/profile
      http://localhost:3000/products
	  http://localhost:3000/orders 

used MERN stack 
   used npm modules package  
   --> bcryptjs (password hashing)
   --> jsonwebtoken (token generation)
   --> dotenv (environment variables)
   --> express
   --> mongoose
   --> cors (Cross Origin Resource Sharing-->to access the different Domains)
   --> react


Created RESTful API's in the format of MVC architechture

--> Models
--> View
--> Controllers
--> middlewares

                            