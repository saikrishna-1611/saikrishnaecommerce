backend port =8080
##routes for frontend
      http://localhost:3000/login
      http://localhost:3000/register
      http://localhost:3000/profile
      http://localhost:3000/products
	  http://localhost:3000/orders